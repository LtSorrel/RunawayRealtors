-- File: city.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create city property/value table

DROP TABLE IF EXISTS city;

CREATE TABLE city(
value SMALLINT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE city OWNER TO group28_admin;

INSERT INTO city (value, property) VALUES (1, 'Kawartha Lakes');

INSERT INTO city (value, property) VALUES (2, 'Oshawa');

INSERT INTO city (value, property) VALUES (3, 'Clarington');

INSERT INTO city (value, property) VALUES (4, 'Whitby');

INSERT INTO city (value, property) VALUES (5, 'Brock');

INSERT INTO city (value, property) VALUES (6, 'Uxbridge');

INSERT INTO city (value, property) VALUES (7, 'Pickering');

INSERT INTO city (value, property) VALUES (8, 'Brooklin');

INSERT INTO city (value, property) VALUES (9, 'Victoria Corner');

INSERT INTO city (value, property) VALUES (10, 'Georgina');

INSERT INTO city (value, property) VALUES (11, 'Ajax');

INSERT INTO city (value, property) VALUES (12, 'Goodwood');

INSERT INTO city (value, property) VALUES (13, 'Courtice');

INSERT INTO city (value, property) VALUES (14, 'Stouville');

INSERT INTO city (value, property) VALUES (15, 'Markham');

