-- File: furnishings.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create property_options property/value table

DROP TABLE IF EXISTS furnishings;

CREATE TABLE furnishings(
value INT PRIMARY KEY,
property CHAR(3) NOT NULL
);

ALTER TABLE furnishings OWNER TO group28_admin;

INSERT INTO furnishings (value, property) VALUES (1, 'Yes');

INSERT INTO furnishings (value, property) VALUES (2, 'No');

