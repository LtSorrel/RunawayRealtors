-- File: bathrooms.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create bathrooms table

DROP TABLE IF EXISTS bathrooms;

CREATE TABLE bathrooms(
	value INT PRIMARY KEY,
	property VARCHAR(30) NOT NULL
);

ALTER TABLE bathrooms OWNER TO group28_admin;

INSERT INTO bathrooms (value, property ) VALUES (1, '1 Bath');
INSERT INTO bathrooms (value, property ) VALUES (2, '1 1/2 Bath');
INSERT INTO bathrooms  (value, property ) VALUES (3, '2 Bath');
INSERT INTO bathrooms  (value, property ) VALUES (4, '2 1/2 Bath');
INSERT INTO bathrooms  (value, property ) VALUES (5, '3 Bath');
INSERT INTO bathrooms  (value, property ) VALUES (6, '3 1/2 Bath');