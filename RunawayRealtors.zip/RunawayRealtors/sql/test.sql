DROP TABLE IF EXISTS persons_test;
CREATE TABLE persons_test (
user_id varchar(50) NOT NULL,
salutation varchar(128) NOT NULL,
last_name varchar(128) NOT NULL,
first_name varchar(128) NOT NULL,
streetAddressOne varchar(128) NOT NULL ,
streetAddressTwo varchar(128),
city varchar(64) NOT NULL,
province varchar(2) NOT NULL,
postal_code char (6) NOT NULL,
primary_phone varchar(15) NOT NULL,
secondary_phone varchar(15),
fax_number varchar (15),
prefered_contact_method char(1) NOT NULL
);
