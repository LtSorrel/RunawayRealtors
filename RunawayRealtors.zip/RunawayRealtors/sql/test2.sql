Drop table if exists tester;

Create Table tester
(

	listing_id int not null Primary Key,
	user_id varchar(50) Not Null REFERENCES users (user_id), 
	status varchar(1) Not Null REFERENCES listing_status (value), 
	price money Not Null, 
	headline varchar(100) Not Null, 
	description varchar(1000) Not Null,
	postal_code varchar(6) Not Null, 
	images INT Default 0 Not Null,
	city smallint not null REFERENCES city (value),
	provinces char(2) not null,
	street varchar(100) not null,
	bedrooms int not null  REFERENCES bedrooms (value),
	bathrooms int not null  REFERENCES bathrooms (value),
	furnishings int not null  REFERENCES furnishings (value),
	property_type int not null REFERENCES property_type (value),
	transaction_type int not null REFERENCES transaction_type (value),
	listed_since date not null,
	house_levels int not null REFERENCES house_levels (value),
	backyard int not null REFERENCES backyard (value)
);

