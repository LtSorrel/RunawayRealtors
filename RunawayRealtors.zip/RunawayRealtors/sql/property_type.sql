-- File: property_options.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create property_type property/value table

DROP TABLE IF EXISTS property_type;

CREATE TABLE property_type(
value INT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE property_type OWNER TO group28_admin;

INSERT INTO property_type (value, property) VALUES (1, 'Residential');
INSERT INTO property_type (value, property) VALUES (2, 'Recreational');
INSERT INTO property_type (value, property) VALUES (3, 'Condo/Strata');
INSERT INTO property_type (value, property) VALUES (4, 'MultiFamily');
INSERT INTO property_type (value, property) VALUES (5, 'Agricultural');