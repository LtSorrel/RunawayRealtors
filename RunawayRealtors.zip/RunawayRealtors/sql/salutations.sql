DROP TABLE IF EXISTS salutations;

CREATE TABLE salutations(
	value INT PRIMARY KEY,
	property CHAR(8) NOT NULL
);

ALTER TABLE salutations OWNER TO group28_admin;

INSERT INTO salutations (value, property) VALUES (1, 'Miss');
INSERT INTO salutations (value, property) VALUES (2, 'Mrs.');
INSERT INTO salutations (value, property) VALUES (3, 'Ms.');
INSERT INTO salutations (value, property) VALUES (4, 'Mistress');
INSERT INTO salutations (value, property) VALUES (5, 'Dr.');
INSERT INTO salutations (value, property) VALUES (6, 'Rev');
INSERT INTO salutations (value, property) VALUES (7, 'Sir');
INSERT INTO salutations (value, property) VALUES (8, 'Mr.');
INSERT INTO salutations (value, property) VALUES (9, 'Master');
