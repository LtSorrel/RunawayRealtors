-- File: backyard.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create backyard 
yard/value table

DROP TABLE IF EXISTS backyard;

CREATE TABLE backyard(
value INT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE backyard OWNER TO group28_admin;

INSERT INTO backyard (value, property ) VALUES (1, '1 acre');
INSERT INTO backyard (value, property ) VALUES (2, '2 acres');
INSERT INTO backyard (value, property ) VALUES (3, '3 acres');
INSERT INTO backyard (value, property ) VALUES (4, '2023.43sq meters');
INSERT INTO backyard (value, property ) VALUES (5, '1011.71sq meters');
INSERT INTO backyard (value, property ) VALUES (6, '140.57sq meters');


