-- File: transaction_type.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create transaction_type property/value table

DROP TABLE IF EXISTS transaction_type;

CREATE TABLE transaction_type(
value INT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE transaction_type OWNER TO group28_admin;

INSERT INTO  transaction_type (value, property ) VALUES (1, 'Purchase');

INSERT INTO transaction_type (value, property ) VALUES (2, 'Rental');

INSERT INTO transaction_type (value, property ) VALUES (3, 'Lease');


