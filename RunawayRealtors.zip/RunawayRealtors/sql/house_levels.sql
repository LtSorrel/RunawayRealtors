-- File: house_levels.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create house_levels 
levels/value table

DROP TABLE IF EXISTS house_levels;

CREATE TABLE house_levels(
value INT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE house_levels OWNER TO group28_admin;

INSERT INTO house_levels (value, property ) VALUES (1, 'Single Story');
INSERT INTO house_levels (value, property ) VALUES (2, 'Two Story');
INSERT INTO house_levels (value, property ) VALUES (3, 'Three Story');
INSERT INTO house_levels (value, property ) VALUES (4, 'Four Story');