-- File: bedrooms.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create bedrooms table

DROP TABLE IF EXISTS bedrooms;

CREATE TABLE bedrooms(
value INT PRIMARY KEY,
property VARCHAR(2) NOT NULL
);

ALTER TABLE bedrooms OWNER TO group28_admin;

INSERT INTO bedrooms (value, property) VALUES (1, '1');
INSERT INTO bedrooms (value, property) VALUES (2, '1+');
INSERT INTO bedrooms (value, property) VALUES (3, '2');
INSERT INTO bedrooms (value, property) VALUES (4, '2+');
INSERT INTO bedrooms (value, property) VALUES (5, '3');
INSERT INTO bedrooms (value, property) VALUES (6, '3+');