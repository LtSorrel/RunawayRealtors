DROP TABLE IF EXISTS preferred_contact_method;

CREATE TABLE preferred_contact_method(
value SMALLINT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE bedrooms OWNER TO group28_admin;

INSERT INTO preferred_contact_method (value, property) VALUES (1, 'Phone');
INSERT INTO preferred_contact_method (value, property) VALUES (2, 'Email');
INSERT INTO preferred_contact_method (value, property) VALUES (3, 'Post');
