DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users(
	user_id VARCHAR(50) PRIMARY KEY,
	password VARCHAR(32) NOT NULL,
	email_address VARCHAR(256) NOT NULL,
	user_type VARCHAR(2) NOT NULL,
	enrol_date DATE NOT NULL,
	last_access DATE NOT NULL
);

ALTER TABLE users OWNER TO group28_admin;

INSERT INTO users VALUES(
	'jdoe',
	'md5',
	'jdoe@dcmail.ca',
	'c',
	'2018-1-1',
	'2019-2-2'
);
INSERT INTO users VALUES(
	'ydoe',
	'md4',
	'ydoe@dcmail.ca',
	's',
	'2018-1-1',
	'2019-2-2'
);
INSERT INTO users VALUES(
	'hdoe',
	'md3',
	'hdoe@dcmail.ca',
	'c',
	'2018-1-1',
	'2019-2-2'
);
INSERT INTO users VALUES(
	'qdoe',
	'md2',
	'qdoe@dcmail.ca',
	'a',
	'2018-1-1',
	'2019-2-2'
);
