-- File: amenities.sql
-- Author: Sarah McCann-Hughes
-- Date: 10/11/2019
-- Description: SQL file to create amenities 
amenity/value table

DROP TABLE IF EXISTS amenities;

CREATE TABLE amenities(
value INT PRIMARY KEY,
property VARCHAR(30) NOT NULL
);

ALTER TABLE amenities OWNER TO group28_admin;

INSERT INTO amenities (value, property ) VALUES (1, 'On Site Laundry');

INSERT INTO amenities (value, property ) VALUES (2, 'Close To Downtown');

INSERT INTO amenities (value, property ) VALUES (3, 'Waterfront');

INSERT INTO amenities (value, property ) VALUES (4, 'Lawn Maintenance');

INSERT INTO amenities (value, property ) VALUES (5, 'Patio');

INSERT INTO amenities (value, property ) VALUES (6, 'Hardwood Floors');

INSERT INTO amenities (value, property) VALUES (7, 'Fireplace');

INSERT INTO amenities (value, property) VALUES (8, 'Gas Heating');

INSERT INTO amenities (value, property) VALUES (9, 'Electric Heating');

INSERT INTO amenities (value, property) VALUES (10, 'Walk-In Closets');

INSERT INTO amenities (value, property) VALUES (11, 'Bus Stop Nearby');

INSERT INTO amenities (value, property) VALUES (12, 'Open Floor Plan');

INSERT INTO amenities (value, property) VALUES (13, 'Newly Renovated');

INSERT INTO amenities (value, property) VALUES (14, 'Parking Space');

INSERT INTO amenities (value, property) VALUES (15, 'Large Windows/ Natural Light');

INSERT INTO amenities (value, property) VALUES (16, 'Backyard');

INSERT INTO amenities (value, property) VALUES (17, 'Pet Friendly');

INSERT INTO amenities (value, property) VALUES (18, 'Private Balcony');

INSERT INTO amenities (value, property) VALUES (19, 'Security');

INSERT INTO amenities (value, property) VALUES (20, 'Swimming Pool');
