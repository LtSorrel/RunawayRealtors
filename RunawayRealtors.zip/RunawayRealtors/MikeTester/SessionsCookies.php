<?php
	// Sessions and cookies
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Session and Cookies
	</title>
</head>
<body>
	

	<?php

		// Checking if a cookie is set
		if (isset($_COOKIE["userid"]))
		{
			// Cookie Set
		}
		else
		{
			// No Cookie was set
		}

		// Create Cookie - Name of cookie, Content of Cookie, Expiry time
		setcookie("nameOfCookie", "ThisIsACookie", time() + 2592000);

		// Get stuff out of cookie
		$dataFromCookie = $_COOKIE["nameOfCookie"];

		// Delete Cookie - Set time to a second ago
		setcookie("nameOfCookie", "ThisIsACookie", time() - 1);

		// Create a session
		$_SESSION["nameOfSessionVariable"] = "FOO";
		$_SESSION["varTwo"] = "bar";

		// Get stuff from session
		$dataFromSession = $_SESSION["varTwo"];

		// Destroy session
		unset($_SESSION["varTwo"]);
		session_destroy();
	?>


</body>
</html>