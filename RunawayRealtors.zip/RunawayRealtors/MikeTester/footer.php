

<h1 align = "center"><u>Visit Us At One Of Our Popular Locations!</u></h1>
<p>
  Kawartha Lakes<br>
  Oshawa <br>
  Clarington<br>
  Whitby <br>
  Brock <br>
  Uxbridge<br>
  Pickering <br>
  Brooklin <br>
  Victoria Corner<br>
  Georgina <br>
  Ajax <br>
  Goodwood <br>
  Courtice <br>
  Whitchurch-Stouffville <br>
  Markham<br>
</p>
<a href="http://validator.w3.org/check?uri=referer">
  <img 	style="width:88px;
  height:31px;"
  src="http://www.w3.org/Icons/valid-xhtml10"
  alt="Valid XHTML 1.0 Strict" />
</a>
<a href="http://jigsaw.w3.org/css-validator/check/referer">
  <img 	style="width:88px;
  height:31px;"
  src="http://jigsaw.w3.org/css-validator/images/vcss"
  alt="Valid CSS!" />
</a>
</body>
</html>
