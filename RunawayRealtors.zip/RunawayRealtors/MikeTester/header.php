
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
$User_ID = "Mike";
ob_start();
session_start();
//require "includes/constants.php";
//require "includes/db.php";
//require "includes/functions.php";

 ?>
 <meta name="keywords" content="" />
 <meta name="description" content="" />
 <link href="css/default.css" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
  <div id="Container">
    <div id="Header">
      <div class="Logo">
        <img src = "images/Logo.jpg" alt = "logo" class ="center">
      </div>
      <div class="Name">
        <h1><a href="http://opentech.durhamcollege.org/webd3201/group28/index.php"><span>Runaway</span>Realtors.ca</a></h1>
      </div>

      <div class="SignIn">
        <h3>SignIn </h3><img src="images/signIn.png" alt="">
      </div>

    </div>
    <div id="Menu">
    <ul>
      <li class="first current_page_item"><a href="http://opentech.durhamcollege.org/webd3201/group28/index.php" accesskey="1" title="">Home</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/listings.php" accesskey="2" title="">Find Your Home</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/Locations.php" accesskey="3" title="">Contact A Realtor</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/Careers.php" accesskey="4" title="">Join Our Team</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/AboutUs.php" accesskey="5" title="">About Us</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/Advice.php" accesskey="6" title="">Advice</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/welcome.php" accesskey="7" title="">Welcome</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/dashboard.php" accesskey="8" title="">Staff</a></li>
      <li><a href="http://opentech.durhamcollege.org/webd3201/group28/admin.php" accesskey="9" title="">Managment</a></li>
    </ul>
  </div>






<h1 align = "center"><u>Visit Us At One Of Our Popular Locations!</u></h1>
<p>
  Kawartha Lakes<br>
  Oshawa <br>
  Clarington<br>
  Whitby <br>
  Brock <br>
  Uxbridge<br>
  Pickering <br>
  Brooklin <br>
  Victoria Corner<br>
  Georgina <br>
  Ajax <br>
  Goodwood <br>
  Courtice <br>
  Whitchurch-Stouffville <br>
  Markham<br>
</p>
<a href="http://validator.w3.org/check?uri=referer">
  <img 	style="width:88px;
  height:31px;"
  src="http://www.w3.org/Icons/valid-xhtml10"
  alt="Valid XHTML 1.0 Strict" />
</a>
<a href="http://jigsaw.w3.org/css-validator/check/referer">
  <img 	style="width:88px;
  height:31px;"
  src="http://jigsaw.w3.org/css-validator/images/vcss"
  alt="Valid CSS!" />
</a>

</div>

</body>
</html>
