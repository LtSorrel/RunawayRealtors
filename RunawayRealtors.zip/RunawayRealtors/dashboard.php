<?php
require("header.php");

if($_SESSION["user_id"] == "")
{
  header("Location:login.php");
  setcookie("loginMessage","You cant access this page");
}
elseif ($_SESSION["user_type"] == CLIENT)
{
header("Location:index.php");
}
?>

<div id="page">
  <?php
   echo $_COOKIE["loginMessage"];
  setcookie("loginMessage","", time()-1);
  ?>
  <div id="featured-wrapper">
    <div class="content">
      <div id="box1">
        <table width="100%" height="100%">
          <caption></caption >
            <thead>
              <tr>
                <th style="background-color:#5e5e5e; color:#fff;"><u>Member Since: 02/10/2019</u></th>
              </tr>
              <tr>
                <th style="background-color:#5e5e5e; color:#fff;"><u>Status:</u></th>
              </tr>
              <tr>
                <th style="background-color:#5e5e5e; color:#fff; width:33%" align ="center"><u>Unique ID: </u></th>
                <th style="background-color:#5e5e5e; color:#fff; width:33%" align="center"><u>Houses Sold: 1,000</u></th>
                <th style="background-color:#5e5e5e; color:#fff; width:33%" align="center"><u>Current Listings: 40</u></th>
              </tr>
              <tr>
                <td align="center">
                  <strong><img src="./images/DashboardTestPhoto.jpg" alt="" border="2" Height="200" width="200"></strong><br>
                  <?php echo "$UserID " ?><br>
                  Acme Billing Co.<br>
                  123 Main St.<br>
                  Cityville, NA 12345<br>
                </td>
                <td align="center">
                  <img src="./images/DashboardSold.png" alt="" border="0" height="200" width="200">
                </td>
                <td align ="center">
                  <img src="./images/CurrentListings.png" alt="" border="" height="200" width="300">
                </td>
              </tr>
              <tr>
                <th align ="center" valign="top" style="background-color:#5e5e5e; color:#fff;" ><u>Reviews</u></th>
                <th align="center" style="background-color:#5e5e5e; color:#fff;">
                  <u>Create Listing</u></th>
                  <th align="center" style="background-color:#5e5e5e; color:#fff;">
                    <u>Edit Listing</u></th>
                  </tr>
              <tr>
                <td></td>
                <td align="center">
                  <a href= "http://opentech.durhamcollege.org/webd3201/group28/DashboardCreateListings.php"><img src="./images/CreateListing.jpg" alt="" border="" height="200" width="200"></a>
                </td>
                <td align="center">
                  <a href ="http://opentech.durhamcollege.org/webd3201/group28/DashboardEditListings.php"><img src="./images/EditListing.svg" alt="" border="" height="200" width="200"></a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


<?php
require("footer.php");
?>
