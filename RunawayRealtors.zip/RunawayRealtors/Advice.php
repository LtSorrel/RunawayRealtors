<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--[if IE 6]>
<link href="default_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body>
    <?php
require("header.php");
?>

	<div id="page">
		<div class="content">
        </div>
	</div>
	<div id="featured-wrapper">
		<div id="box1">
                At Runaway Realtors we know that planning to Buy or Sell can be tough or confusing. To make the transition easier, we have provided websites that will go into more detail about What you need to know about buying or selling a house <i>before</i> you make your decision. If you have any more questions, feel free to contact your <a href = "http://opentech.durhamcollege.org/webd3201/group28/Locations.php">nearest</a> Realtor to ask them personally.
        </div>
        
<div id="box3">
			
</div>
       <p><a href="https://www.mymoneycoach.ca/blog/tips-for-buying-a-house-for-first-time-home-buyers.html?gclid=CjwKCAjwldHsBRAoEiwAd0JybUiK746clSE2FIgCkbQRlgNWPxwfwi8G6LbuYcOSZtQstEDPwS0yTBoCVIcQAvD_BwE">Tips On Purchasing With A Mortgage</a></p>
        <p><a href="https://www.daveramsey.com/blog/tips-for-first-time-home-buyers">Tips For First Time Home Buyers</a></p>
        <p><a href="https://www.moneytalksnews.com/20-clues-youre-buying-home-the-right-neighborhood/">Tips For Choosing A Location</a></p>
         <p><a href="https://www.hgtv.com/design/decorating/design-101/10-best-kept-secrets-for-selling-your-home">Tips For Selling Your Home</a></p>
         <p><a href="https://www.investopedia.com/articles/mortgages-real-estate/08/home-seller-mistakes-selling-house.asp">Mistakes To Avoid When Selling</a></p>
         <p><a href="https://wemovetheworld.com/blog/packing-tips-getting-started/">Tips For Moving</a></p>
        
	</div>
    
<?php
require("footer.php");
?>