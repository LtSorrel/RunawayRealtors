<?php
require "header.php";

if ($_SESSION['user_id'] <> "")
{
	//	setcookie("user_id", "$login", time() - 1);
    unset($_SESSION['user_id']);
		unset($_SESSION['last_access']);
		unset($_SESSION['user_type']);
  //  session_destroy();
    setcookie("user_id", $login, time() - 1);
    setcookie("loginMessage","You have been sucessfully logged out.");

    session_destroy();
}
header("location:login.php");

?>
