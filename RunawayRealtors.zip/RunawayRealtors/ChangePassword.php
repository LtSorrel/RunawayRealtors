<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--[if IE 6]>
<link href="default.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body>
    <?php
require("header.php");
?>

	<div id="page">
	</div>
	<div id="featured-wrapper">
		<div id="box1">
            <div class="content">
<div class="model" id="password_model">
    <div class="model-header">
        <h3><center>Change Password</center> <span class="extra-title muted"></span></h3>
    </div>
    <div class="model-body form-horizontal">
        <div class="control-group">
            <label for="userid" class="control-label"><center>User ID</center></label>
            <div class="controls">
                <center><input type="id" name="userid"></center>
            </div>
        </div>
        <div class="control-group">
            <label for="new_password" class="control-label"><center>New Password</center></label>
            <div class="controls">
                <center><input type="password" name="new_password"></center>
            </div>
        </div>
        <div class="control-group">
            <label for="confirm_password" class="control-label"><center>Confirm Password</center></label>
            <div class="controls">
                <center><input type="password" name="confirm_password"></center>
            </div>
        </div>      
    </div>
    <div class="modal-footer">
        <center><button href="#" class="btn" data-dismiss="model" aria-hidden="true">Close</button></center>
        <center><button href="#" class="btn btn-primary" id="password_model_save">Save Changes</button></center>
        <center><button href="#" class="btn btn-primary" id="password_model_save"><a href = "http://opentech.durhamcollege.org/webd3201/group28/login.php">Return To Login</a></button></center>
    </div>
</div>
        </div>
			 </div>
		<div id="box2">
			
		</div>
		<div id="box3">
			
		</div>
	</div>
<?php
require("footer.php");
?>
    </body>
</html>
