<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--[if IE 6]>
<link href="default_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body>
    <?php
require("header.php");
?>

	<div id="page">
		<div class="content" style="background-color:#EF6C33;">
      <h1>
        Runaway Realtors mission is to modernize and progress the experience of buying and selling real estate by cultivating a spirit of collaboration, innovation, and integrity.<br><br>

        <h1><i>“The Agency fosters a culture of partnership in which all clients and listings are represented in a cooperative environment by all its agents, thereby ensuring its clients and listings have the competitive edge.”  - Mauricio Umansky, CEO and co-founder. </i></h1><br>

        <h1><i>“Leveraging the most emergent technologies and social media strategies, The Agency envisions itself as more than just a real estate brokerage; it is a lifestyle company committed to informing and connecting global communities.” Billy Rose, President and co-founder.</i></h1>
        <br>
        <br>


        <h1>Runaway Realtors values teamwork and interdisciplinary collaboration as a path to insight and excellence in our work. Our company’s team of committed professionals embrace the following core values:
          <br><br>
          <li><u>Quality:</u> We deliver only excellence and aim to exceed expectations in everything we do.</li>
          <br>
          <li><u>Integrity:</u> We conduct ourselves in the highest ethical standards, demonstrating honesty and fairness in every decision and action.</li>
          <br>
          <li><u>Agility:</u>We execute expeditiously to address our clients’ needs.
            Courage: We make decisions and act in the best interests of our clients, even in the face of personal or professional adversity.</li>
            <br>
            <li><u>Respect and Trust:</u>We treat our clients and each other with dignity and respect at all times.</li>
            <br>
            <li><u>Fun:</u>We believe in having fun at work and with each other.</li>
            <br>

          </h1>
        </h1>
      </div>
    </div>


<?php
require("footer.php");
?>
