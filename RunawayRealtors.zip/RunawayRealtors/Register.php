<?php
require "header.php";
db_connect();
if($_SESSION["user_id"] <> "")
{
  header("Location:index.php");
}



if($_SERVER["REQUEST_METHOD"] == "GET")
{
	//default mode when the page loads the first time
	//can be used to make decisions and initialize variables
	$User_ID = "";
	$salutation = "";
	$First_Name = "";
	$Last_Name = "";
	$Street1 = "";
	$Street2 = "";
	$City = "";
	$Province = "";
	$Postal_code = "";
	$Primary = "";
	$Secondary = "";
	$Contact = "";
	$Fax = "";
	$User_Password = "";
	$Confirm_Password = "";
	$Email = "";
	unset($_SESSION["Salutation_Dropdown"]);
	unset($_SESSION["City_Dropdown"]);
	unset($_SESSION["Province_Dropdown"]);
	unset($_SESSION["Contact_Radio"]);
	//unset($_SESSION["User_type"]);
	$output = "";
	$error = "";
}
else if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$_SESSION["Salutation_Dropdown"] = $_POST["Salutation_Dropdown"];
	$_SESSION["City_Dropdown"] = $_POST["City_Dropdown"];
	$_SESSION["Province_Dropdown"] = $_POST["Province_Dropdown"];
	$_SESSION["Contact_Radio"] = $_POST["Contact_Radio"];
	$First_Name = $_POST["first_name"];
	$Last_Name = $_POST["last_name"];
	$Street1 = $_POST["street1"];
	$Street2 = $_POST["street2"];
	$Email = $_POST["email"];
	$Postal_code = $_POST["postal_code"];
	$Primary = $_POST["primary"];
	$Secondary = $_POST["secondary"];
	$Fax = $_POST["fax"];
	$Confirm_Password = $_POST["confirm"];
	$User_ID = $_POST["User_ID"];
	$User_Password = $_POST["password"];
  $type = $_POST["type"];
	$output = "";
	$date = date("Y-m-d",time());

	// VALIDATION

	if (!isset($User_ID) || $User_ID == "")
	{
		$output = "Must enter User ID<br/>";
	}
	elseif (is_user_id($User_ID) == 1)
	{
		$output = "User ID already exists<br/>";
	}

	if (!isset($_SESSION["Salutation_Dropdown"]) || $_SESSION["Salutation_Dropdown"] == "")
	{
		$output .= "Must enter Salutation<br/>";
	}

	// Makes sure first name fits criteria
	if (!isset($First_Name) || $First_Name == "")
	{
	  $output .= "You did not enter your first name</br>";
	}
	elseif (preg_match('#[0-9]#',$First_Name))
	{
	  $output .= "First name cannot contain numbers.</br>";
	  $First_Name = "";
	}

	// Makes sure last name fits criteria
	if (!isset($Last_Name) || $Last_Name == "")
	{
	  $output .= "You did not enter your last name</br>";
	}
	elseif (preg_match('#[0-9]#',$Last_Name))
	{
	  $output .= "Last name cannot contain numbers.</br>";
	  $Last_Name = "";
	}

	// Makes sure phone number fits criteria
	if (!isset($type) || $type == "")
	{
	  $output .= "You did not enter a user type</br>";
	}

	if (!isset($_SESSION["Province_Dropdown"]) || $_SESSION["Province_Dropdown"] == "-- Select --")
	{
		$output .= "Must enter Province<br/>";
	}

	if (!isset($_SESSION["City_Dropdown"]) || $_SESSION["City_Dropdown"] == "-- Select --")
	{
		$output .= "Must enter City<br/>";
	}

	// Makes sure phone number fits criteria
	if (!isset($Street1) || $Street1 == "")
	{
	  $output .= "You did not enter an Address</br>";
	}

	// Makes sure Postal Code fits criteria
	if (!isset($Postal_code) || $Postal_code == "")
	{
		$output .= "You did not enter Postal Code</br>";
	}
	elseif (strlen(Remove_Extra($Postal_code)) <> 6)
	{
	  $output .= "Postal code must be 6 characters.</br>";
	  $Postal_code = "";
	}
	else
	{
		$Postal_code = Remove_Extra($Postal_code);
	}

	// Makes sure Phone Number fits criteria
	if (!isset($Primary) || $Primary == "")
	{
		$output .= "You did not enter a Primary Number</br>";
	}
	elseif (preg_match('#[a-z]#',$Primary))
	{
		$output .= "Phone Number cannot contain letters.</br>";
		$Primary = "";
	}
	elseif (strlen(Remove_Extra($Primary)) >= 15 or strlen(Remove_Extra($Primary)) < 10)
	{
	  $output .= "Primary number cannot be less than 10 or over 15 digits.</br>";
	  $Primary = "";
	}
	else
	{
		$Primary = Remove_Extra($Primary);
	}

	if ($Secondary <> "")
	{
		if (preg_match('#[a-z]#',$Secondary))
		{
			$output .= "Secondary Phone Number cannot contain letters.</br>";
			$Secondary = "";
		}
		elseif (strlen(Remove_Extra($Secondary)) >= 15 or strlen(Remove_Extra($Secondary)) < 10)
		{
	  	$output .= "Secondary number cannot be less than 10 or over 15 digits.</br>";
	  	$Secondary = "";
		}
		else
		{
			$Secondary = Remove_Extra($Secondary);
		}
	}

	if ($Fax <> "")
	{
		if (preg_match('#[a-z]#',$Fax))
		{
			$output .= "Fax Number cannot contain letters.</br>";
			$Fax = "";
		}
		elseif (strlen(Remove_Extra($Fax)) >= 15 or strlen(Remove_Extra($Fax)) < 10)
		{
	  	$output .= "Fax Number cannot be less than 10 or over 15 digits.</br>";
	  	$Fax = "";
		}

		else
		{
			$Fax = Remove_Extra($Fax);
		}
	}

	if (!isset($_SESSION["Contact_Radio"]) || $_SESSION["Contact_Radio"] == "-- Select --")
	{
		$output .= "Must enter Preferred method<br/>";
	}

	// Makes sure email fits criteria
	if (!isset($Email) || $Email == "")
	{
	  $output .= "You did not enter an Email</br>";
	}
	elseif (!(filter_var($Email, FILTER_VALIDATE_EMAIL)))
	{
	  $output .= $Email . " is not a valid Email. Please try again.</br>";
	  $Email = "";
	}
	elseif (is_email($Email) == 1)
	{
	  $output .= "This email is already in use. Please try again.</br>";
	  $Email = "";
	}


	if (!isset($User_Password) || $User_Password == "")
	{
		$output .= "Must enter password</br>";
		$User_Password = "";
		$Secondary = "";
	}

	if ($User_Password <> $Confirm_Password)
	{
		$output .= "Passwords do not match";
		$User_Password = "";
		$Secondary = "";
	}
	if ($output == "")
	{

		if($type == 'a')
		{
			$type = 'p';
		}
		$salutation = $_SESSION["Salutation_Dropdown"];
		$city = $_SESSION["City_Dropdown"];
		$province = $_SESSION["Province_Dropdown"];
		$contact = $_SESSION["Contact_Radio"];
		//$results = pg_execute("check_user", array($login));
		pg_execute("Create_User",array($User_ID,$User_Password,$Email,$type,$date));
		pg_execute("Register", array($User_ID,$salutation,$Last_Name,$First_Name,$Street1,$Street2,$city,$province,$Postal_code,$Primary,$Secondary,$Fax,$contact));

		setcookie("loginMessage","You have been sucessfully registered.");
		header("location:login.php");

	}
		//generate the table
	  //echo "$User_ID,$User_Password,$Email,p,$date, $date";
		//echo "$User_ID,{$_SESSION["Salutation_Dropdown"]},$First_Name,$Last_Name,$Street1,$Street2,{$_SESSION["City_Dropdown"]},{$_SESSION["Province_Dropdown"]},$Postal_code,$Primary,$Secondary,$Fax,{$_SESSION["Contact_Radio"]}";

}

	?>

	<div id="page">
		<?php if($output<>"")
			echo "<p style=\"text-align: center; font-size:15pt; \">$output</p>"; //display the output
		?>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<table class="form" style="table-layout:fixed">
				<tr>
					<th colspan="4">Register</th>
				</tr>
				<tr>
				<td colspan="4">
					<label style="text-align:center; display:block">User Name</label>
					<input type="text" style="width:85%" name="User_ID" size="10" value="<?php echo $User_ID; ?>"/></td>
			</tr>
				<tr>
					<td style="padding-left:3%;padding-right:-3%">
						<label style="text-align:center; display:block">Salutation</label>
	          <?php
	            build_simple_dropdown_register("Salutation_Dropdown");
	          ?>
					</td>
					<td style="padding-right:3%;" colspan="3">
						<label style="text-align:center; display:block">First Name</label>
						<input type="text" style="width:85%" name="first_name" size="10" value="<?php echo $First_Name; ?>"/></td>
				</tr>
				<tr>
					<td style="padding-left:3%;padding-right:-3%">
						<label style="text-align:center; display:block">User Type</label>
						 <select name="type" style="width:90%; margin-left:10%; margin-right:5%; border-radius:5px;" >
					  	<option>-- Select --</option>
							<option <?php if($type=="c") echo 'selected="selected"'; ?> value="c">Client</option>
							<option <?php if($type=="a") echo 'selected="selected"'; ?>value="a">Agent</option>
						</select>
						</td>
					<td style="padding-right:3%;" colspan="3">
						<label style="text-align:center; display:block">Last Name</label>
						<input style="width:85%" type="text" name="last_name" size="10" value="<?php echo $Last_Name; ?>"/></td>
				</tr>
				<tr>
					<td colspan="4"><label style="margin-top:10px;text-align:center; display:block">Location</label><hr/></td>
				</tr>
				<tr >
					<td style="padding-left:3%;padding-right:-3%">
						<label style="text-align:center; display:block">Province</label>
						<?php
	            build_simple_dropdown_register("Province_Dropdown");
	          ?>
					</td>
						<td  style="padding-right:9%;" colspan="3">
							<label style="text-align:center; display:block">City</label>
							<?php
		            build_simple_dropdown_register("City_Dropdown");
		          ?>
						</td>
					</tr>
				<tr>
					<td colspan="4">
						<label style="text-align:center; display:block">Address 1</label>
						<input type="text" style="width:85%" name="street1" size="10" value="<?php echo $Street1; ?>"/></td>
				</tr>
				<tr>
					<td colspan="4">
						<label style="text-align:center; display:block">Address 2</label>
						<input type="text" style="width:85%" name="street2" size="10" value="<?php echo $Street2; ?>"/></td>
				</tr>
				<tr>
					<td style="padding-left:4%" colspan="1">
						<label style="text-align:center; display:block">Postal Code</label>
						<input type="text" style="width:85%" name="postal_code" size="10" value="<?php echo $Postal_code; ?>"/></td>
					</tr>
					<tr>
						<td colspan="4"><label style="margin-top:10px;text-align:center; display:block">Contact</label><hr/></td>
					</tr>
					<tr>
						<td colspan="4">
							<label style="text-align:center; display:block">Email</label>
							<input type="text" style="width:85%" name="email" size="10" value="<?php echo $Email; ?>"/></td>
					</tr>
					<tr>
						<td colspan="4">
							<label style="text-align:center; display:block">Primary Phone Number</label>
							<input type="text" style="width:85%" name="primary" size="10" value="<?php echo $Primary; ?>"/></td>
					</tr>
					<tr>
						<td colspan="4">
							<label style="text-align:center; display:block">Secondary</label>
							<input type="text" style="width:85%" name="secondary" size="10" value="<?php echo $Secondary; ?>"/></td>
					</tr>
					<tr>
						<td colspan="4">
							<label style="text-align:center; display:block">Fax</label>
							<input type="text" style="width:85%" name="fax" size="10" value="<?php echo $Fax; ?>"/></td>
					</tr>
					<tr>
					<td colspan="4">
					<label style="text-align:center; display:block; margin-top:10px; margin-bottom:10px;">Preferred Contact Method</label>
					  <?php
					  	build_radio("Contact_Radio");
					  ?>
				</td>
			</tr>
				<tr>
					<td colspan="4"><label style="margin-top:10px;text-align:center; display:block">Confirm</label><hr/></td>
				</tr>
				<tr>
					<td colspan="4">
						<label style="text-align:center; display:block">Password</label>
						<input type="password" style="width:85%" name="password" size="10" value=""/></td>
				</tr>
				<tr>
					<td colspan="4">
						<label style="text-align:center; display:block">Confirm Password</label>
						<input type="password" style="width:85%" name="confirm" size="10" value=""/></td>
				</tr>
				<tr>
					<td colspan="4">
						<button class="button-style-alt" style="width:85%" type="reset" name="reset" value="Reset" onclick="document.location.href='Register.php'">Reset</button>
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<button class="button-style-alt" style="width:85%" type="submit" name="submit" value="Login">Register</button>
					</td>
				</tr>
			</table>


		</form>
	</div>
	<?php
	include("footer.php")
	?>
