<?php
require("header.php");
$UserID = $_SESSION["user_id"];
$UserType = $_SESSION["user_type"];

if ( $UserType <> "s" )
{
  header("location:index.php");
}
?>

	<div id="page">
		<div class="content" style="background-color:#EF6C33; padding:100px; margin-bottom:150px;">
      <h1 class="center">Welcome Back Admin <?php echo "$UserID " ?></h1>

    </div>
  </div>

<?php
require("footer.php");
?>
