<?php

$status = Array(
	"O",
	"C",
	"H",
	"S"
	);	

$words = Array (
	"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
	irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
	Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
	"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
	"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque ea
	rum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat."
	);
 $letters = Array(
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z"
  );
for ($count=0; $count < 10; $count++) {
	
	mt_srand();
	
	$generate_list_id          = mt_rand(1, 10000000); //Done
	$generate_user_id          = mt_rand(1, 10000000); //Done
	$generate_status           = mt_rand($status); //Done
	$generate_price            = mt_rand(150000, 1000000); //Done
	$generate_headline         = mt_rand($words); //Generate random lorem ipsum array
	$generate_description 	   = mt_rand($words); //Generate random lorem ipsum array
	$generate_postal_code 	   = $letters[mt_rand(0, count($letters) -1)] + mt_rand(0, 9) + $letters[mt_rand(0, count($letters) -1)] + mt_rand(0, 9) + $letters[mt_rand(0, count($letters) -1)] + mt_rand(0, 9) + $letters[mt_rand(0, count($letters) -1)] + mt_rand(0, 9);
	$generate_images	  	   = mt_rand(1, 150); //Scrap images, then assign them array values.
	$generate_city		  	   = mt_rand(1, 15); //Create a city array
	$generate_property_options = mt_rand(1, 5); //Get random primary keys from this table
	$generate_bedrooms         = mt_rand(1, 5); //Foreign key
	$generate_bathrooms        = mt_rand(1, 5); //Foreign key
	$generate_furnishings      = mt_rand(1, 2); //Foreign key
	$generate_property_type    = mt_rand(1, 5); //Foreign key
	$generate_transaction_type = mt_rand(1, 3); //Foreign key
    $generate_listed_since     = mt_rand(1, 50); //Foreign key
	$generate_property_type    = mt_rand(1, 5); //Foreign key
	$generate_amenities        = mt_rand(1, 20); //Foreign key
	$generate_house_levels     = mt_rand(1, 4); //Foreign key
	$generate_backyard		   = mt_rand(1, 6); //Foreign key
	
	$query = "INSERT INTO TABLE Listings (listing_id, user_id, status, price, headline, description, postal code, images, city, property_options, 
									   bedrooms, bathrooms, furnishings, property_type, lot_size, amenities, house_levels, backyard) 
						  VALUES ($generate_list_id, $generate_user_id, $generate_status, $generate_price, $generate_headline, $generate_description, 
					      $generate_postal_code, $generate_images, $generate_city, $generate_property_options, $generate_bedrooms,$generate_bathrooms,
					      $generate_furnishings, $generate_property_type, $generate_transaction_type, $generate_listed_since, $generate_property_type,
					      $generate_lot_size, $generate_amenities, $generate_house_levels, $generate_backyard)";
	
	echo $query;
?>