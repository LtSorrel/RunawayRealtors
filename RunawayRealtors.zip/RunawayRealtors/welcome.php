<?php
include "header.php";
$UserID = $_SESSION["user_id"];
$UserType = $_SESSION["user_type"];

if ( $UserType == "a" || $UserType == "" )
{
  header("location:index.php");
}
?>

<div id="page">
  <div class="content" style="background-color:#EF6C33; padding:100px; margin-bottom:150px;">
    <h1 align = "center">Welcome Back <?php echo "$UserID " ?></h1>
    <p align = "center"> Please Proceed To Desired Page!</p>
  </div>
</div>

<?php
include ("footer.php")
?>
