<?php
require "header.php";

if($_SESSION["user_id"] == "")
{
	if($_SERVER["REQUEST_METHOD"] == "GET")
	{
		$login = $_COOKIE["user_id"];
		$error = $_COOKIE["loginMessage"];

		if( $error == "You cant see me" )
		{
			echo "<img src=\"images\No.gif\" alt=\"Nope\" style=\"width:100%\">";

		}
		setcookie("loginMessage", "ThisIsACookie", time() - 1);
		$password = "";
		$type = "";
		$date = "";
	}

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		if (isset($_COOKIE['user_id']))
		{
			$login = $_COOKIE["user_id"];
		}
		else
		{
			$login = trim($_POST["login"]);
		}

		$password = trim($_POST["password"]);
		$type = trim($_POST["type"]);

		if (!isset($login) || $login == "")
		{
			$error .= "Must enter User ID<br/>";
		}

		if (!isset($password) || $password == "")
		{
			$error .= "Must enter password<br/>";
		}
		$conn = db_connect();

		if (is_user_id($login) <> 1)
		{
			$login ="";
			$error = "User Does not exist";
		}
	}


	if( $_REQUEST["user_id"] || $_REQUEST["password"] )
	{

		$sql = pg_execute("find_user", array("$login", "$password"));

		if(pg_num_rows($sql))
		{
			// Sets login
			$_SESSION['user_id'] = $login;

			// Gets last date
			$sql = pg_execute("find_date", array("$login"));
			$_SESSION['last_access'] = pg_fetch_result($sql, "last_access");

			// Updates date to current date and time
			$sql = pg_execute("update_date", array("$login"));

			// Find User Type
			$sql = pg_execute("find_type", array("$login"));
			$_SESSION['user_type'] = pg_fetch_result($sql, "user_type");


			setcookie("user_id", "$login", time() + 2592000);

			if ($_SESSION['user_type'] == CLIENT)
			{
				 header("Location:welcome.php");
			   ob_flush();
			}
			if ($_SESSION['user_type'] == ADMIN)
			{
				 header("Location:admin.php");
				 ob_flush();
			}
			if ($_SESSION['user_type'] == AGENT)
			{
				 header("Location:dashboard.php");
				 ob_flush();
			}
		}
		else
		{
			$error .= "Either the user id and or the password was incorrect";
		}
	}
}
else
{
	header("Location:index.php");
}
	?>

		<div id="page" style="padding:140px;">
			<h3 style="text-align:center"><?php echo $error; ?></h3>
			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];  ?>" >
				<table class="form">
					<tr>
						<td style="padding-top:30px;">
							<label style="text-align:center; display:block">User Name</label>
							<input style="width:85%" type="text" name="login" value="<?php echo $login; ?>" size="30" />
						</td>
					</tr>
					<tr>
						<td>
							<label style="text-align:center; display:block">Password</label>
							<input style="width:85%" type="password" name="password" value="" size="30" />
						</td>
					</tr>
					<tr>
						<td>
							<a href="http://opentech.durhamcollege.org/webd3201/group28/Register.php">Register today!</a>
						</td>
					</tr>
					<tr>
						<td>
							<a href="http://opentech.durhamcollege.org/webd3201/group28/ChangePassword.php">Forget your password?</a>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<button class="button-style-alt" type="submit" name="Login" value="Login">Login</button></td>
						</tr>
					</table>

				</form>
			</div>


<?php
require("footer.php");
 ?>
