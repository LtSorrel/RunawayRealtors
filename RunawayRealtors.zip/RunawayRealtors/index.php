<?php
require("header.php");
?>

<div id="page">
	<div class="center">
	</div>
	<div id="featured-wrapper">
		<div id="box1" class="center" style="height:350px;">
			<h1>Featured Listings</h1>
			<div style="float: left; width:33%">
				<a href = "">
					<img class="hoverdetail" src ="images/house1.jpg" height="250px" width="100%" alt="House1"/>
				</a>
				<p>Matt Damon, Runaway Realtor<br/><span style="color:#316be0">$500,000</span><br/>123 Fake St. ON L1J 4DD</p>

			</div>
			<div style="display: inline-block; text-align: center;width:33%">
				<a href = "">
					<img class="hoverdetail" src ="images/house2.jpg" height="250px" width="100%" alt="House2"/>
				</a>
				<p>Matt Damon, Runaway Realtor<br/><span style="color:#316be0">$500,000</span><br/>123 Fake St. ON L1J 4DD</p>
			</div>
			<div style="display: inline-block; float: right; width:33%">
				<a href = "">
					<img class="hoverdetail" src ="images/house3.jpg" height="250px" width="100%" alt="House3"/>
				</a>
				<p>Matt Damon, Runaway Realtor<br/><span style="color:#316be0">$500,000</span><br/>123 Fake St. ON L1J 4DD</p>
			</div>

		</div>
		<div id="box2">
			<h2>Thousands of Listings<br/>
				<span>One Perfect Home</span></h2>
				<ul class="style4" style="text-decoration:underline;">
					<li>Canada's #1 Trusted Realtors</li>
					<li>Feel At Home Anywhere!</li>
					<li>Search Thousands Of Homes In Dozens Of Cities!</li>
					<li>Quick, Easy, Painless</li>
					<li>Find The Home That's Right For You</li>
					<li>Dozens Of Agents Ready To Help</li>
				</ul>
			</div>
			<div id="box3" class="center" style="width: 30%; height:380px;">
				<h1>Want To Spice Up Your New Home? Try These Tantalizing Recipies!</h1>
				<a href = "https://www.gogogogourmet.com/refreshing-summer-pitcher-drinks/">
					<img src ="./images/SummerDrinks.jpeg"  width="100%" alt="ad"/>
				</a>
			</div>
		</div>
	</div>

<?php
require("footer.php");
?>
