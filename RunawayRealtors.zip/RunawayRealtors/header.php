
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php

ob_start();
session_start();
require "includes/constants.php";
require "includes/db.php";
require "includes/functions.php";
$type = $_SESSION["user_type"];
$user = $_SESSION["user_id"];
 ?>
<title>Runaway Realtors</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="css/default.css" rel="stylesheet" type="text/css" media="all" />
<!--[if IE 6]>
<link href="default_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->

</head>
<body>
<div id="wrapper" class="container" >
<div id="header">
	<div id="logo">
		<h1><a href="http://opentech.durhamcollege.org/webd3201/group28/index.php"><span>Runaway</span>Realtors</a></h1>
					<img src = "images/Logo.jpg" alt = "logo" class ="center" style="height: 50%"/>
		<p>Your Getaway Experts</p>
	</div>
  <div id="signin">
    <?php

      $user= $_COOKIE["user_id"];

      if($type <> "")
      {
          echo "<p> Welcome back $user <a href=\"http://opentech.durhamcollege.org/webd3201/group28/logout.php\" title=\"\">Logout</a></p>";
      }
      else
      {
          echo "<p><a href=\"http://opentech.durhamcollege.org/webd3201/group28/login.php\" title=\"\">Login</a></p>";
      }

     ?>

  </div>
	<div id="menu">
		<ul>
			<li><a href="http://opentech.durhamcollege.org/webd3201/group28/index.php" accesskey="1" title="">Home</a></li>
			<li><a href="http://opentech.durhamcollege.org/webd3201/group28/listings.php" accesskey="2" title="">Find Your Home</a></li>
			<li><a href="http://opentech.durhamcollege.org/webd3201/group28/Locations.php" accesskey="3" title="">Contact</a></li>
			<li><a href="http://opentech.durhamcollege.org/webd3201/group28/Careers.php" accesskey="4" title="">Join Our Team</a></li>
			<li><a href="http://opentech.durhamcollege.org/webd3201/group28/AboutUs.php" accesskey="5" title="">About Us</a></li>
			<li><a href="http://opentech.durhamcollege.org/webd3201/group28/Advice.php" accesskey="6" title="">Advice</a></li>
    </ul>

    <ul>
      <li style="display:none"></li>
      <?php
        if($_SESSION['user_type'] == CLIENT)
        {
          echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/welcome.php\" accesskey=\"7\" title=\"\">Welcome</a></li> ";
        //  echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/logout.php\" title=\"\">Logout</a></li>";
        }
        elseif ($_SESSION['user_type'] == ADMIN)
        {
          echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/welcome.php\" accesskey=\"7\" title=\"\">Welcome</a></li> ";
          echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/dashboard.php\" accesskey=\"8\" title=\"\">Staff</a></li> ";
          echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/admin.php\" accesskey=\"9\" title=\"\">Managment</a></li> ";
        //  echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/logout.php\" title=\"\">Logout</a></li>";
        }
        elseif ($_SESSION['user_type'] == AGENT)
        {
          echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/dashboard.php\" accesskey=\"8\" title=\"\">Staff</a></li> " ;
      //    echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/logout.php\" title=\"\">Logout</a></li>";
        }
        else
        {
        //  echo "<li><a href=\"http://opentech.durhamcollege.org/webd3201/group28/login.php\" title=\"\">Login</a></li> ";
        }

       ?>
		</ul>
	</div>
</div>
