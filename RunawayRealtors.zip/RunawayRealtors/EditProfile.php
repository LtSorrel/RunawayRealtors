<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<?php
require "header.php";
$host = "host = localhost";
$port = "port = 5432";
$dbname = "dbname = webdusers";
$credentials = "user = mccannhughess password = SilverKnot";
if($_SERVER["REQUEST_METHOD"] == "GET")
{
	//default mode when the page loads the first time
	//can be used to make decisions and initialize variables
	$User_ID = "";
	$User_Password = "";
	$Confirm_Password = "";
	$Security_Question = "";
	$Security_Answer = "";
	$output = "";
	$error = "";
}
else if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$User_ID = $_POST["User_ID"];
	$User_Password = $_POST["User_Password"];
	$output = "";
	$date = "date(\"Y-m-d\",time())";

	//connect
	$conn = pg_connect("$host $port $dbname $credentials ");

	if (!isset($User_ID) || $User_ID == "")
	{
		$output = "Must enter User ID<br/>";
	}

	if (!isset($User_Password) || $User_Password == "")
	{
		$output .= "Must enter password";
	}

	if ($User_Password <> $Confirm_Password)
	{
		$output .= "Passwords Must Match";
	}

	//issue the query
	$sql = "SELECT *
	FROM webdusers
	WHERE ID = '$User_ID'";

	$result = pg_query($conn, $sql);
	$records = pg_num_rows($result);

	if ( $output == "" )
	{
		if ( pg_fetch_result($result,"ID") <> "" )
		{
			if ( $User_Password == pg_fetch_result($result, "password") )
			{
				$output .= "<h3>Welcome Back " . pg_fetch_result($result, "first_name") . " " . pg_fetch_result($result, "last_name"); ;
					$output .= "</br> Our records show that your email is " . pg_fetch_result($result, "email");
					$output .= "</br> and you last accessed our system: " . pg_fetch_result($result, "last_access") . "</br></h3>";


					$sql = "UPDATE webdusers
					SET last_access = '$date'
					WHERE ID = '$User_ID' ";

				}
				else {
					$output = "Password is incorrect";
					$User_Password = "";
				}
			}
			else
			{
				$output = "User doenst Exist";
			}
		}
		//generate the table
		echo $output; //display the output

	}

	?>

	<div id="page">
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<table class="form">
				<tr>
					<th><u>Edit Your Profile Information</u></th>
				</tr>
                <tr>
					<td><input type="text" placeholder="Salutation" style="width:400px" name="salutation" size="10" value="<?php echo $salutation; ?>"/></td>
				</tr>
				<tr>
					<td><input type="text" placeholder="First Name" style="width:400px" name="first_name" size="10" value="<?php echo $first_name; ?>"/></td>
				</tr>
				<tr>
					<td colspan="2"><input style="width:400px;" placeholder="Last Name" type="text" name="last_Name" size="10" value="<?php echo $last_name; ?>"/></td>
				</tr>
				<tr>
					<td colspan="2"><input type="text" placeholder="Email" style="width:400px" name="Email" size="10" value="<?php echo $email; ?>"/></td>
				</tr>
				<tr>
					<td colspan="2"><input type="text" placeholder="Password" style="width:400px" name="Password" size="10" value=""/></td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td colspan="2"><input type="dropdown" placeholder="Confirm Password" style="width:400px" name="Conf" size="10" value=""/></td>
				</tr>
                <tr>
					<td colspan="2">
						<button class="button-style-alt" style="width:415px" type="submit" name="submit" value="Update" ><a href ="http://opentech.durhamcollege.org/webd3201/group28/login.php">Update Your Profile</a></button>
					</td>
				</tr>
			</table>


		</form>
	</div>
	<?php
	include("footer.php")
	?>
