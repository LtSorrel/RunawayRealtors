<?php
require("header.php");
if($_SESSION["user_id"] == "")
{
  header("Location:login.php");
  setcookie("loginMessage","You cant access that page");
}
elseif ($_SESSION["user_type"] == CLIENT)
{
  header("Location:index.php");
}

  if($_SERVER["REQUEST_METHOD"] == "GET")
  {
    //default mode when the page loads the first time
    //can be used to make decisions and initialize variables
    $status = "";
    $price = "";
    $headline = "";
    $description = "";
    $postal_code = "";
    $images = "";
    $city = "";
    //$property = "";

   //$_SESSION["Status_Dropdown"] = "s";
    $_SESSION["Status_Dropdown"] = array();
    unset($_SESSION["Bed_Dropdown"]);
    unset($_SESSION["Bath_Dropdown"]);
    unset($_SESSION["Floor_Dropdown"]);
    unset($_SESSION["Amenities_Dropdown"]);
    unset($_SESSION["Furnished_Dropdown"]);
    unset($_SESSION["Transaction_Dropdown"]);
    unset($_SESSION["Property_Dropdown"]);
    unset($_SESSION["Province_Dropdown"]);
    unset($_SESSION["City_Dropdown"]);
    unset($_SESSION["Lot_Dropdown"]);

  }
  else if($_SERVER["REQUEST_METHOD"] == "POST")
  {
    $price = $_POST["price"];
    $headline = $_POST["headline"];
    $description = $_POST["description"];
    $postal_code = $_POST["pcode"];
    $street = $_POST["street"];
    $images= $_POST["images"];
    $date = $_POST["date"];

    //$_SESSION["Salutation_Dropdown"] = $_POST["Salutation_Dropdown"];
    $_SESSION["Status_Dropdown"] = $_POST["Status_Dropdown"];
    $_SESSION["Bed_Dropdown"] = $_POST["Bed_Dropdown"];
    $_SESSION["Bath_Dropdown"] = $_POST["Bath_Dropdown"];
    $_SESSION["Floor_Dropdown"] = $_POST["Floor_Dropdown"];
    // $_SESSION["Amenities_CheckBoxs"] = $_POST["Amenities_CheckBoxs"];
    $_SESSION["Furnished_Dropdown"] = $_POST["Furnished_Dropdown"];
    $_SESSION["Transaction_Dropdown"] = $_POST["Transaction_Dropdown"];
    $_SESSION["Property_Dropdown"] = $_POST["Property_Dropdown"];
    $_SESSION["Province_Dropdown"] = $_POST["Province_Dropdown"];
    $_SESSION["City_Dropdown"] = $_POST["City_Dropdown"];
    $_SESSION["Lot_Dropdown"] = $_POST["Lot_Dropdown"];

    $output = "";


    if (!isset($headline) || $headline == "")
    {
      $output = "Must enter a headline<br/>";
    }
    if (!isset($_SESSION["Status_Dropdown"]) ||  $_SESSION["Status_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter a status<br/>";
    }
    if (!isset($date) ||  $date == "")
    {
      $output .= "Must enter listed since<br/>";
    }
    if (!isset($price) ||  $price == "")
    {
      $output .= "Must enter a price<br/>";
    }
    elseif (preg_match('#[a-z]#',$price))
    {
      $output .= "Price cannot contain letters<br/>";
      $price = "";
    }

    if (!isset($_SESSION["Transaction_Dropdown"]) ||  $_SESSION["Transaction_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter transaction type<br/>";
    }

    if (!isset($_SESSION["Province_Dropdown"]) ||  $_SESSION["Province_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter province<br/>";
    }

    if (!isset($_SESSION["City_Dropdown"]) ||  $_SESSION["City_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter city<br/>";
    }
    // Makes sure Postal Code fits criteria
    if (!isset($postal_code) || $postal_code == "")
    {
      $output .= "You did not enter Postal Code</br>";
    }
    elseif (strlen(Remove_Extra($postal_code)) <> 6)
    {
      $output .= "Postal code must be 6 characters.</br>";
      $postal_code = "";
    }
    else
    {
      $postal_code = Remove_Extra($postal_code);
    }

    if (!isset($street) || $street == "")
    {
      $output .= "You did not enter a street</br>";
    }

    if (!isset($_SESSION["Bed_Dropdown"]) ||  $_SESSION["Bed_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter number of bedrooms<br/>";
    }
    if (!isset($_SESSION["Bath_Dropdown"]) ||  $_SESSION["Bath_Dropdown"] == "-- Select --")
  	{
  		$output .= "Must enter number of bathrooms<br/>";
  	}
    if (!isset($_SESSION["Floor_Dropdown"]) ||  $_SESSION["Floor_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter number of floors<br/>";
    }
    if (!isset($_SESSION["Furnished_Dropdown"]) ||  $_SESSION["Furnished_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter funishing type<br/>";
    }
    if (!isset($_SESSION["Property_Dropdown"]) ||  $_SESSION["Property_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter type of property<br/>";
    }
    if (!isset($_SESSION["Lot_Dropdown"]) ||  $_SESSION["Lot_Dropdown"] == "-- Select --")
    {
      $output .= "Must enter lot size<br/>";
    }

    if (!isset($images) ||  $images == "")
  	{
  		$output .= "Must enter a image<br/>";
  	}
    else if (preg_match('#[a-z]#',$images))
    {
      $output .= "Images can only be numeric<br/>";
      $images = "";
    }
    if (!isset($description) ||  $description == "")
    {
      $output .= "Must enter a description<br/>";
    }

    if ($output == "")
    {
      db_connect();
      $status = $_SESSION["Status_Dropdown"];
      $beds = $_SESSION["Bed_Dropdown"];
      $baths = $_SESSION["Bath_Dropdown"];
      $floors = $_SESSION["Floor_Dropdown"];
      $funish = $_SESSION["Furnished_Dropdown"];
      $tranaction = $_SESSION["Transaction_Dropdown"];
      $User = $_SESSION["user_id"];
      $property = $_SESSION["Property_Dropdown"];
      $province = $_SESSION["Province_Dropdown"];
      $city = $_SESSION["City_Dropdown"];
      //
      // $date = '2019-10-30';
      $size = $_SESSION["Lot_Dropdown"];
      $int = number() + 1;
      // $user = "ydoe";
      // $status = 'c';
      // $price = 1000;
      // $headline = "Ger";
      // $description = "Get";
      // $postal_code = "k2k2k2";
      // $images = 1;
      // $city = 1;
      // $province = "ON";
      // $street = "123";
      // $beds = 1;
      // $baths = 1;
      // $funish = 1;
      // $property = 1;
      // $tranaction = 1;
      // $floors = 1;
      // $size = 1;
      pg_execute("tester", array($int, $user, $status, $price, $headline, $description, $postal_code, $images, $city, $province,  $street, $beds, $baths, $funish, $property, $tranaction, $date, $floors, $size));
      header("location:dashboard.php");
      setcookie("loginMessage","You have been sucessfully created a listing.");
    //  echo "$int, $user, $status, $price, $headline, $description, $postal_code, $images, $city, $province,  $street, $beds, $baths, $funish, $property, $tranaction, $date, $floors, $size";
      }

  }
  $conn = db_connect();

  ?>

  <div id="page">
    <?php
   echo "<p style=\"text-align:center; font-size:15pt;\">$output</p>";
     ?>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <table class="form" style="margin-bottom: 50px; width: 90%; table-layout:fixed">
        <tr>
          <th colspan="4">Create Listing</th>
        </tr>
        <tr>
          <td colspan="4" style="width:20%">
            <label style="text-align:center; display:block;">Headline</label>
            <input type="text" style="width:90%; margin-left:5%; margin-right:5%"  name="headline" size="10" value="<?php echo $headline; ?>"/>
          </td>
        </tr>
        <tr>
          <td colspan="2">
            <label style="text-align:center; display:block">Status</label>
            <?php
              build_simple_dropdown("Status_Dropdown");
            ?>
          </td>
          <td colspan="2" style=" padding-left:5%;padding-right:15%">
              <label style="text-align:center; display:block">Listed Since</label>
              <input type="text" style="width:100%; margin-left:0px; margin-right:0px" name="date" size="10" value="<?php echo $date?>"/></td>
        </tr>
        <!-- <tr>
        <td colspan="4">
        <label style="text-align:center; display:block; margin-top:10px; margin-bottom:10px;">Contact Method</label>
        //  <?php
        //  build_radio("Contact_Radio");
        //  ?>
      </td>
    </tr> -->
    <tr>
      <td style="padding-left:5%">
        <label style="text-align:center; display:block">Price</label>
        <input type="text" style="width:100%; margin-left:0px; margin-right:0px" name="price" size="10" value="<?php echo $price?>"/></td>
        <td colspan="3" style="padding-left:1% ; padding-right:45%">
          <label style="text-align:center; display:block">Transaction</label>
          <?php
            build_simple_dropdown("Transaction_Dropdown");
          ?>
        </td>
      </tr>
      <tr>
        <td colspan="4"><label style="margin-top:10px;text-align:center; display:block">Location</label><hr/></td>
      </tr>
      <tr>
        <td style="padding-left:3%">
          <label style="text-align:center; display:block">Province</label>
          <?php
            build_simple_dropdown("Province_Dropdown");
          ?>
          <!-- <input type="text" style="width:100%; margin-right:0px"  name="province" size="10" value="<?php echo $province; ?>"/> -->
        </td>
        <td colspan="3" style=" padding-left:1%; padding-right:45%">
          <label style="text-align:center; display:block">City</label>
          <?php
            build_simple_dropdown("City_Dropdown");
          ?>
          <!-- <input type="text" style="width:100%;margin-right:0px"  name="city" size="10" value="<?php echo $city; ?>"/> -->
        </td>
      </tr>
      <tr>
        <td style="padding-left:4%">
          <label style="text-align:center; display:block">Postal Code</label>
          <input type="text" style="width:94%; margin-right:0px"  name="pcode" size="10" value="<?php echo $postal_code; ?>"/>
        </td>
        <td colspan="3" style="padding-left:-50px">
          <label style="text-align:center; display:block">Street</label>
          <input type="text" style="width:82%; padding-right:5%"  name="street" size="10" value="<?php echo $street; ?>"/>
        </td>
      </tr>
      <tr>
        <td colspan="4"><label style="margin-top:10px;text-align:center; display:block">About</label><hr/></td>
      </tr>
      <tr>
        <td style="padding-left:3%">
          <label style="text-align:center; display:block">Bedrooms</label>
          <?php
            build_simple_dropdown("Bed_Dropdown");
          ?>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="bedrooms" size="10" value="<?php echo $bedrooms; ?>"/> -->
        </td>
        <td style="padding-left:0px" >
          <label style="text-align:center; display:block">Bathrooms</label>
          <?php
            build_simple_dropdown("Bath_Dropdown");
          ?>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="bathrooms" size="10" value="<?php echo $bathrooms; ?>"/> -->
        </td>
        <td>
          <label style="text-align:center; display:block">Floors</label>
          <?php
            build_simple_dropdown("Floor_Dropdown");
          ?>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="floors" size="10" value="<?php echo $house_levels; ?>"/> -->
        </td>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="parking" size="10" value="<?php echo $parking; ?>"/> -->
      </tr>
      <tr>
        <td style="padding-left:3%">
          <label style="text-align:center; display:block">Furnished</label>
          <?php
            build_simple_dropdown("Furnished_Dropdown");
          ?>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="furnished" size="10" value="<?php echo $furnished; ?>"/> -->
        </td>
        <td style="padding-left:0px" >
          <label style="text-align:center; display:block">Property Type</label>
          <?php
            build_simple_dropdown("Property_Dropdown");
          ?>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="property" size="10" value="<?php echo $property_type; ?>"/> -->
        </td>
        <td>
          <label style="text-align:center; display:block">Lot Size</label>
          <?php
            build_simple_dropdown("Lot_Dropdown");
          ?>
          <!-- <input type="text" style="width:90%; margin-right:0px"  name="floors" size="10" value="<?php echo $lot_size; ?>"/> -->
        </td>
      </tr>
        <!-- <tr>
          <td colspan="4"><label style="margin-top:10px;text-align:center; display:block">Amenities</label><hr></td>
        </tr> -->
        <!-- <tr> -->
          <!-- <td colspan="4"> -->
            <!-- <input type="checkbox" name="1" value="1" style="margin-left:-20%; margin-right:-44%;">one<br/> -->
          <!--
            // build_checkboxs("Amenities_CheckBoxs");
          //
         </td> -->
        <!-- </tr> -->
        <tr>
          <td colspan="4"><label style="margin-top:10px;text-align:center; display:block">Description</label><hr/></td>
        </tr>

      <tr>
        <td colspan="4" style="margin-top:10px">
          <label style="text-align:center; display:block">Photos</label>
          <input type="text" style="width:90%; margin-right:0px"  name="images" size="10" value="<?php echo $images; ?>"/>
        </td>
      </tr>
      <tr>
        <td colspan="4" style="margin-top:10px">
          <label style="text-align:center; display:block">Description</label>
          <textarea style="width:90%; border-radius: 5px;margin-left:5%; margin-right:5%; height:200px" name="description" rows="25" cols="1"><?php echo $description; ?></textarea>
        </td>
      </tr>
      <tr>
        <td colspan="4">
          <button class="button-style-alt" id="ListingClear" style="width:90%; padding-left:2%" type="reset" name="reset" value="Reset" onclick="document.location.href='DashboardCreateListings.php'">Reset</button>
        </td>
      </tr>
      <tr>
        <td colspan="4">
          <button id="ListingSubmit" class="button-style-alt" type="submit" name="submit" value="Login">Create</button>
        </td>
      </tr>
    </table>


  </form>
</div>

<?php
require("footer.php");
?>
