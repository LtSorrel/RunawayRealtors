<?php
// date
// match_user "UPDATE users SET last_access = '" . date("Y-m-d",time()) . "' WHERE user_id = '" . $login . "'" ;
// update_date "SELECT last_access FROM  users WHERE user_id = '".$login."'";
// user_type $sql = "SELECT user_type FROM  users WHERE user_id = '".$login."'";

function db_connect()
{
  $conn = pg_connect("host=".DB_HOST." dbname=".DB_NAME." user=".DB_USER." password=".DB_PASSWORD );

  pg_prepare($conn, "find_user", 'SELECT * FROM users WHERE user_id = $1 AND password = $2');
  pg_prepare($conn, "find_date", 'SELECT last_access FROM users WHERE user_id = $1');
  pg_prepare($conn, "find_type", 'SELECT user_type FROM users WHERE user_id = $1');
  pg_prepare($conn, "update_date", 'UPDATE users SET last_access = date("Y-m-d",time()) WHERE user_id = $1');

  pg_prepare($conn, "find_number", 'SELECT listing_id FROM tester');

  pg_prepare($conn, "tester", 'INSERT INTO tester (listing_id, user_id, status, price , headline , description , postal_code, images, city, provinces, street, bedrooms, bathrooms, furnishings, property_type, transaction_type, listed_since, house_levels, backyard )
   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)');

  pg_prepare($conn, "check_user", 'SELECT * FROM users WHERE user_id = $1');
  pg_prepare($conn, "check_email", 'SELECT * FROM users WHERE email_address = $1');

  pg_prepare($conn, "Status_Dropdown", 'SELECT * FROM listing_status');
  pg_prepare($conn, "Salutation_Dropdown", 'SELECT * FROM salutations');
  pg_prepare($conn, "Bed_Dropdown", 'SELECT * FROM bedrooms');
  pg_prepare($conn, "Bath_Dropdown", 'SELECT * FROM bathrooms');
  pg_prepare($conn, "Floor_Dropdown", 'SELECT * FROM house_levels');
  pg_prepare($conn, "Furnished_Dropdown", 'SELECT * FROM furnishings');
  pg_prepare($conn, "Transaction_Dropdown", 'SELECT * FROM transaction_type');
  pg_prepare($conn, "Property_Dropdown", 'SELECT * FROM property_type');
  pg_prepare($conn, "Province_Dropdown", 'SELECT * FROM provinces');
  pg_prepare($conn, "City_Dropdown", 'SELECT * FROM city');
  pg_prepare($conn, "Lot_Dropdown", 'SELECT * FROM backyard ');
  pg_prepare($conn, "Since_Dropdown", 'SELECT * FROM listed_since');

  //pg_prepare($conn, "Amenities_CheckBoxs", 'SELECT * FROM amenities');

  pg_prepare($conn, "Contact_Radio", 'SELECT * FROM preferred_contact_method');
  pg_prepare($conn, "Create_User", 'INSERT INTO users (user_id, password, email_address,user_type, enrol_date, last_access) VALUES ($1,$2,$3,$4,$5,$5)');
  pg_prepare($conn, "Register", 'INSERT INTO persons_test (user_id, salutation, last_name, first_name, streetAddressOne, streetAddressTwo, city, province , postal_code, primary_phone, secondary_phone, fax_number, prefered_contact_method)
   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)');
	return $conn;
}

function number()
{
  $results = pg_execute("find_number", array());
  return pg_num_rows($results);
}

function is_user_id($login)
{
  $results = pg_execute("check_user", array($login));
  return pg_num_rows($results);
}

function is_email($email)
{
  $results = pg_execute("check_email", array($email));
  return pg_num_rows($results);
}


// Dynamically builds radio buttons
function build_radio($Table)
{
  $selection = $_COOKIE["contactRadio"];
  $results = pg_execute("$Table", array());

  $old = $_SESSION["$Table"];
  while($rows = pg_fetch_assoc($results))
  {
    $value = $rows['value'];
    $display = $rows['property'];
    echo "<input type=\"radio\" name=\"$Table\" value=\"$value\" style=\"margin-top:10px; margin-left:0%; margin-right:-41%\"". (($old==$value)?'checked="checked"':"")."/>$display<br/>";
  }
}

function build_checkboxs($Table)
{
  $results = pg_execute("$Table", array());
  $count = 1;
  echo "<div style=\"text-align:left\">";
  $test = $_SESSION["$Table"];
  while($rows = pg_fetch_assoc($results))
  {
      $display = $rows['property'];
      $value = $rows['value'];

      echo "<input type=\"checkbox\" name=\"$Table\" value=\"$value\" style=\"margin-left:0%; margin-right:-44%\"". (($test==$value)?'selected="selected"':"").">$display<br/>";

  }
    echo "</div>";
}

// Dynamically builds a dropdown
function build_simple_dropdown($Table)
{
  $results = pg_execute("$Table", array());

  echo "<select name=\"$Table\" style=\"width:90%; margin-left:10%; margin-right:5%; border-radius:5px;\" >";
  echo "<option>-- Select --</option>";

  $old = $_SESSION["$Table"];
  while($rows = pg_fetch_assoc($results))
  {
    if( $Table == "Province_Dropdown")
    {
      $value = $rows['value'];
      echo "<option value='$value'". (($old==$value)?'selected="selected"':"").">$value</option>";
    }
    else
    {
      $display = $rows['property'];
      $value = $rows['value'];
      echo "<option value='$value'". (($old==$value)?'selected="selected"':"").">$display</option>";
    }
  }
  echo "</select>";

}

function build_simple_dropdown_register($Table)
{
  $results = pg_execute("$Table", array());

  echo "<select name=\"$Table\" style=\"width:90%; margin-left:10%; margin-right:5%; border-radius:5px;\" >";
  echo "<option>-- Select --</option>";

  $old = $_SESSION["$Table"];
  while($rows = pg_fetch_assoc($results))
  {
    if( $Table == "Province_Dropdown")
    {
      $value = $rows['value'];
      echo "<option value='$value'". (($old==$value)?'selected="selected"':"").">$value</option>";
    }
    else
    {
      $display = $rows['property'];
      $value = $rows['value'];
      echo "<option value='$display'". (($old==$display)?'selected="selected"':"").">$display</option>";
    }
  }
  echo "</select>";

}

?>
