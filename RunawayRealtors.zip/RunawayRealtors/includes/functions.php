<?php

function display_copyright()
{?>

  &copy; <?php echo date("Y");?><span style="color:white;">Runaway Realtors</span><?php
}
?>

<?php

function Remove_Extra($string)
{
  $search = array('_','-',' ','(',')','.',',');
  $proper = str_replace($search,"",$string);
  return $proper;
}

?>
