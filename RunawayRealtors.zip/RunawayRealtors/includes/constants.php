<?php

  // Defining the constants for type of user account
  DEFINE('ADMIN', 's');
  DEFINE('AGENT', 'a');
  DEFINE('CLIENT', 'c');
  DEFINE('PENDING', 'p');
  DEFINE('DISABLED', 'd');

  // Contact method contacts
  DEFINE('EMAIL', 'e');
  DEFINE('PHONE', 'p');
  DEFINE('MAIL', 'm');

  // Listing Status
  DEFINE('CLOSED', 'c');
  DEFINE('OPEN', 'o');
  DEFINE('SOLD', 's');

  // Phone Number and Area Code
  DEFINE('AREACODE_MIN', 200);
  DEFINE('AREACODE_MAX', 999);

  // Defining the constants for the database conection
  DEFINE('DB_HOST', '127.0.0.1');
  DEFINE('DB_NAME', 'group28_db');
  DEFINE('DB_PORT', '5432');
  DEFINE('DB_PASSWORD', 'password');
  DEFINE('DB_USER', 'group28_admin');

  // Cookie Lifetime constant
  DEFINE('COOKIE_LIFESPAN', 2592000)

 ?>
