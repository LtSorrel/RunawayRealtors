<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--[if IE 6]>
<link href="default_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body>
    <?php
require("header.php");
?>

	<div id="page">
		<div class="content">
        </div>
	</div>
	<div id="featured-wrapper">
		<div id="box1">
            
<table>
  <tr>
    <th>Kawartha Lakes</th>
      <th>Oshawa</th>
<th>Clarington</th>
<th>Whitby</th>
<th>Brock</th>
      <th>Uxbridge</th>
  </tr>
    
  <tr>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
    <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
<td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
    <br>  Sunday: CLOSED</td>
<br>
 <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>

<br>
  </tr>
    
  <tr>
    <th>Location</th>
<th> Location</th>
<th>Location</th>
<th>Location</th>
<th> Location</th>
<th> Location</th>
  </tr>
    <tr>
        <td>365 VanHorne St.
        <br> Brock ON, 
<br> R5F 6G6
<br> (705)-320-9951 </td>
        <td>1418 St.Paul St.
        <br> Brock ON, 
<br> L9F 4Z6
<br> (705)-320-9951 </td>
        <td>162 Athabasca St.
        <br> Whitby ON, 
<br> HE6 5A4
<br> (705)-320-9951 </td>
    <td>24 Metcalfe St.
        <br> Oshawa ON, 
<br> KFA 4K6
<br> (705)-320-9951 </td>
        <td>123 Sussex St.
        <br> Lindsay ON, 
<br> K9V 4H6
<br> (705)-320-9951 </td>
<td>125 Navy St.
        <br>Clarington ON, 
<br> Z4K 5N9
<br> (705)-320-9951 </td>
  </tr>

</table>

<table>
  <tr>
    <th>Pickering</th>
      <th>Brooklin</th>
<th>Victoria Corner</th>
<th>Georgina</th>
<th>Ajax</th>
      <th>Goodwood</th>
  </tr>
    
  <tr>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
    <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
<td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
    <br>  Sunday: CLOSED</td>
<br>
 <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>

<br>
  </tr>
    
  <tr>
    <th>Location</th>
<th> Location</th>
<th>Location</th>
<th>Location</th>
<th> Location</th>
<th> Location</th>
  </tr>
    <tr>
        <td>541 St. George Blvd.
        <br> Pickering ON, 
<br> J6H 5G5
<br> (905)-325-4458 </td>
        <td>103 50th Av
        <br> Brooklin ON, 
<br> R6T 6G6
<br> (651)-256-9951 </td>
        <td>21 Logy Bay Rd
        <br> Victoria Corner ON, 
<br> H7J 4D2
<br> (658)-223-1125 </td>
    <td>68 Highfield Park Dr.
        <br> Georgina ON, 
<br> R5H 7N8
<br> (220)-525-5987 </td>
        <td>676 Vetrans Dr.
        <br> Ajax ON, 
<br> 6H6 7D7
<br> (401)-665-4485 </td>
<td>252 Wellington St.
        <br>Goodwood ON, 
<br> V6B 9K7
<br> (203)-777-8896 </td>
  </tr>

</table>
            <table>
  <tr>
    <th>Courtice</th>
      <th>Whitechurch - Stouville</th>
<th>Markham</th>

  </tr>
    
  <tr>
      <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
    <td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
<br>  Sunday: CLOSED</td>
<td><u>Hours Of Operation</u>
      <br>
      Mon-Fri: 9:00 am - 7:00 pm
<br>  Saturday: 10:00 am - 7:00 pm
    <br>  Sunday: CLOSED</td>
<br>
  </tr>
    
  <tr>
    <th>Location</th>
<th> Location</th>
<th>Location</th>
  </tr>
    <tr>
        <td>104 Gillingham Dr.
        <br> Courtice ON, 
<br> H8K 4F5
<br> (303)-221-5541 </td>
        <td>400 Woolwitch St.
        <br> Stouville ON, 
<br> R6H 7J8
<br> (665)-325-6651 </td>
        <td>926 Cassels St.
        <br> Markham ON, 
<br> K7M 5F6
<br> (605)-325-8848 </td>
  </tr>

</table>

                   
    </div>
        
<div id="box3">
		
</div>
        
	</div>
    
<?php
require("footer.php");
?>