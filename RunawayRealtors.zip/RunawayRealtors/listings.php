<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Skeleton 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130902

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--[if IE 6]>
<link href="default_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body>
    <?php
require("header.php");
?>
	
		<div id="box1" style="background-image: url(./images/listingbackground.jpg);height:1000px; width:300px border: 1px solid black;background-repeat: no-repeat">
             <h1 align ="center"><u> Find Your Home</u></h1>
        <p align ="center">Please Enter Your Information Below</p>
        <br>
        <br>
<form align = "center">
Location: <br>
        <input type="text" name="location">
        <br>
        <br>
Minumum Price: <br>
<select>
<option value = "0"> Please Select An Option </option>
<option value = "0">$ 0 - 25,000</option>
<option value = "2">$ 25,000 - 75,000</option>
<option value = "3">$ 75,000 - 125,000</option>
<option value = "4">$ 125,000 - 200,000</option>
<option value = "5">$ 200,000 - 275,000</option>
<option value = "6">$ 275,000 - 325,000</option>
<option value = "7">$ 325,000 - 400,000</option>
<option value = "8">$ 400,000 +</option>
    </select>
<br>
<br>
Maximum Price: <br>
<select>
<option value = "0"> Please Select An Option </option>
<option value = "9">$ 0 - 25,000</option>
<option value = "10">$ 25,000 - 75,000</option>
<option value = "11">$ 75,000 - 125,000</option>
<option value = "12">$ 125,000 - 200,000</option>
<option value = "13">$ 200,000 - 275,000</option>
<option value = "14">$ 275,000 - 325,000</option>
<option value = "15">$ 325,000 - 400,000</option>
<option value = "16">$ 400,000 +</option>
</select>
<br>
<br>
Beds: <br>
<select>
<option value = "0"> Please Select An Option </option>
<option value = "9">1</option>
<option value = "10">2</option>
<option value = "11">3+</option>
</select>
<br>
<br>
Bath:<br>
<select>
<option value = "0"> Please Select An Option </option>
<option value = "9">1</option>
<option value = "10">2</option>
<option value = "11">3+</option>
</select>
<br>
<br>
Furnishings:<br>
<input type="radio" name="Furnishing" value="Furnished">Furnished<br>
<input type="radio" name="Furnishing" value="UnFurnished">Un-Furnished<br>
<br>
Property Type <br>
<select>
<option value = "0"> Please Select An Option </option>
<option value = "9">Residential</option>
<option value = "10">Recreational</option>
<option value = "11">Condo/Strata</option>
<option value = "11">MultiFamily</option>
<option value = "11">Agricultural</option>
</select>
<br>
<br>
Transaction Type<br>
<input type="radio" name="Furnishing" value="Furnished">For Sale<br>
<input type="radio" name="Furnishing" value="UnFurnished">For Rent<br>
<br>
Listed Since:<br>
<input type="date" name="listingdate">
<br>
<br>
Building Type: <br>
<select>
<option value = "0"> Please Select An Option </option>
<option value = "9">House</option>
<option value = "9">Row/Townhouse</option>
<option value = "9">Apartment</option>
<option value = "11">Duplex</option>
<option value = "11">Triplex</option>
<option value = "11">Fourplex</option>
    </select>
<br>
<br>
<input type="submit" value="Search">
</form>
			 </div>
       
		
		
		<div id="box3" text-alignment ="left">
			 <?php
require("footer.php");
?>
    </div>
    </body>
</html>